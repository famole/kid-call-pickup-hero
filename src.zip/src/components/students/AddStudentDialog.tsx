
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Class, Child } from '@/types';
import { Loader2 } from "lucide-react";
import { isValidUUID } from '@/utils/validators';
import { useTranslation } from '@/hooks/useTranslation';
import { logger } from '@/utils/logger';

interface AddStudentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  classList: Class[];
  newStudent: Partial<Child>;
  setNewStudent: React.Dispatch<React.SetStateAction<Partial<Child>>>;
  onSave: () => void;
  isLoading?: boolean;
}

const AddStudentDialog = ({
  open,
  onOpenChange,
  classList,
  newStudent,
  setNewStudent,
  onSave,
  isLoading = false
}: AddStudentDialogProps) => {
  const { t } = useTranslation();
  const studentNameId = React.useId();
  const studentClassId = React.useId();
  
  // Validate that the classId is a valid UUID before setting it
  const handleClassChange = (classId: string) => {
    if (isValidUUID(classId)) {
      setNewStudent({...newStudent, classId});
    } else {
      logger.error("Invalid class ID format:", classId);
      // Try to find the actual UUID for this class in the list
      const classItem = classList.find(c => c.id === classId || c.name === classId);
      if (classItem && isValidUUID(classItem.id)) {
        setNewStudent({...newStudent, classId: classItem.id});
      } else {
        logger.error("Could not find a valid UUID for class:", classId);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{t('admin.addStudentTitle')}</DialogTitle>
          <DialogDescription>
            {t('admin.addStudent')}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor={studentNameId} className="required">{t('forms.studentName')}</Label>
            <Input
              id={studentNameId}
              value={newStudent.name || ''}
              onChange={e => setNewStudent({...newStudent, name: e.target.value})}
              placeholder="e.g. John Doe"
              required
              autoFocus
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor={studentClassId} className="required">{t('admin.class')}</Label>
            <Select
              value={newStudent.classId || ''}
              onValueChange={handleClassChange}
              required
            >
              <SelectTrigger id={studentClassId}>
                <SelectValue placeholder={t('admin.selectClass')} />
              </SelectTrigger>
              <SelectContent>
                {classList.map((classItem) => (
                  <SelectItem key={classItem.id} value={classItem.id}>
                    {classItem.name} ({classItem.grade})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => {
              setNewStudent({ name: '', classId: '', parentIds: [] });
              onOpenChange(false);
            }}
            disabled={isLoading}
          >
            {t('admin.cancel')}
          </Button>
          <Button 
            onClick={onSave}
            disabled={!newStudent.name || !newStudent.classId || isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {t('admin.saving')}
              </>
            ) : (
              t('admin.saveStudent')
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddStudentDialog;
