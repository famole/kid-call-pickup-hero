import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Calendar, Users, Clock } from "lucide-react";
import { Child, Class } from '@/types';
import { supabase } from "@/integrations/supabase/client";
import { getCurrentParentIdCached } from '@/services/parent/getCurrentParentId';
import { getPickupAuthorizationsForStudent, deletePickupAuthorization } from '@/services/pickupAuthorizationService';
import { useTranslation } from '@/hooks/useTranslation';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@/utils/logger';
import { useDeleteConfirmation } from '@/hooks/useDeleteConfirmation';
import DeleteConfirmationDialog from '@/components/ui/delete-confirmation-dialog';
import AdminAuthorizationForm from '../pickup-authorization/AdminAuthorizationForm';

interface StudentDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  student: Child | null;
  getClassName: (classId: string) => string;
  classList: Class[];
}

interface StudentParentRelation {
  id: string;
  parentId: string;
  parentName: string;
  relationship?: string;
  isPrimary: boolean;
  parentEmail?: string;
  parentPhone?: string;
}

interface PickupAuthorization {
  id: string;
  authorizedParentId: string;
  authorizedParentName: string;
  authorizedParentEmail: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  createdAt: string;
}

const StudentDetailsDialog: React.FC<StudentDetailsDialogProps> = ({
  open,
  onOpenChange,
  student,
  getClassName,
  classList,
}) => {
  const { t, getCurrentLanguage } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [parentRelations, setParentRelations] = useState<StudentParentRelation[]>([]);
  const [pickupAuthorizations, setPickupAuthorizations] = useState<PickupAuthorization[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  const deleteConfirmation = useDeleteConfirmation<PickupAuthorization>({
    onDelete: async (auth) => {
      const currentParentId = await getCurrentParentIdCached();
      if (!currentParentId) {
        toast({
          title: t('common.error'),
          description: 'Authentication required',
          variant: 'destructive'
        });
        return;
      }
      await deletePickupAuthorization(currentParentId, auth.id);
      toast({
        title: t('common.success'),
        description: t('studentDetails.authorizationDeleted')
      });
      handleAuthorizationCreated();
    },
    getItemName: (auth) => auth.authorizedParentName,
    getConfirmationText: (auth) => ({
      title: t('studentDetails.confirmDeleteAuth'),
      description: t('studentDetails.deleteAuthDescription', { parentName: auth.authorizedParentName })
    })
  });

  useEffect(() => {
    if (!student || !open) {
      setParentRelations([]);
      setPickupAuthorizations([]);
      return;
    }

    const fetchStudentDetails = async () => {
      setIsLoading(true);
      logger.log('Fetching student details for student:', student.id);
      
      try {
        // Fetch parent relationships with parent details
        const { data: relations, error } = await supabase
          .from('student_parents')
          .select(`
            id,
            parent_id,
            relationship,
            is_primary,
            parents!inner(
              name,
              email,
              phone
            )
          `)
          .eq('student_id', student.id);

        if (error) {
          logger.error('Error fetching student relations:', error);
        } else {
          const parentData: StudentParentRelation[] = relations.map(rel => ({
            id: rel.id,
            parentId: rel.parent_id,
            parentName: rel.parents?.name || 'Unknown Parent',
            relationship: rel.relationship || undefined,
            isPrimary: rel.is_primary,
            parentEmail: rel.parents?.email,
            parentPhone: rel.parents?.phone,
          }));

          setParentRelations(parentData);
        }

        // Fetch pickup authorizations using the service helper
        logger.log('Fetching pickup authorizations for student ID:', student.id);

        try {
          const authorizations = await getPickupAuthorizationsForStudent(student.id);

          const authData: PickupAuthorization[] = authorizations.map(auth => ({
            id: auth.id,
            authorizedParentId: auth.authorizedParentId,
            authorizedParentName: auth.authorizedParent?.name || 'Unknown Parent',
            authorizedParentEmail: auth.authorizedParent?.email || '',
            startDate: auth.startDate,
            endDate: auth.endDate,
            isActive: auth.isActive,
            createdAt: auth.createdAt,
          }));

          logger.log('Final pickup authorizations data:', authData);
          setPickupAuthorizations(authData);
        } catch (authError) {
          logger.error('Error fetching pickup authorizations:', authError);
          setPickupAuthorizations([]);
        }
      } catch (error) {
        logger.error('Error in fetchStudentDetails:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchStudentDetails();
  }, [student, open]);

  const handleAuthorizationCreated = () => {
    // Refresh the authorizations list
    if (student) {
      const fetchAuthorizations = async () => {
        try {
          const authorizations = await getPickupAuthorizationsForStudent(student.id);
          const authData: PickupAuthorization[] = authorizations.map(auth => ({
            id: auth.id,
            authorizedParentId: auth.authorizedParentId,
            authorizedParentName: auth.authorizedParent?.name || 'Unknown Parent',
            authorizedParentEmail: auth.authorizedParent?.email || '',
            startDate: auth.startDate,
            endDate: auth.endDate,
            isActive: auth.isActive,
            createdAt: auth.createdAt,
          }));
          setPickupAuthorizations(authData);
        } catch (error) {
          console.error('Error refreshing authorizations:', error);
        }
      };
      fetchAuthorizations();
    }
  };

  if (!student) return null;

  const isAdmin = user?.role === 'admin' || user?.role === 'superadmin';
  const classInfo = classList.find(c => c.id === student.classId);
  const initials = student.name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase();

  const formatDate = (dateString: string) => {
    const locale = getCurrentLanguage() === 'es' ? 'es-ES' : 'en-US';
    // Parse date in local timezone to avoid timezone conversion issues
    const [year, month, day] = dateString.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    return date.toLocaleDateString(locale, { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const isExpired = (endDate: string) => {
    // Compare only dates, not times - authorization should be valid through end of day
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    // Parse date in local timezone
    const [year, month, day] = endDate.split('-');
    const end = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    end.setHours(0, 0, 0, 0);
    return end < today;
  };

  const isActive = (startDate: string, endDate: string) => {
    // Compare only dates, not times - authorization should be valid through end of day
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    // Parse dates in local timezone
    const [startYear, startMonth, startDay] = startDate.split('-');
    const start = new Date(parseInt(startYear), parseInt(startMonth) - 1, parseInt(startDay));
    start.setHours(0, 0, 0, 0);
    const [endYear, endMonth, endDay] = endDate.split('-');
    const end = new Date(parseInt(endYear), parseInt(endMonth) - 1, parseInt(endDay));
    end.setHours(0, 0, 0, 0);
    return today >= start && today <= end;
  };

  const getAuthorizationStatus = (startDate: string, endDate: string) => {
    if (isExpired(endDate)) return { label: t('studentDetails.expired'), variant: 'destructive' as const };
    if (isActive(startDate, endDate)) return { label: t('studentDetails.active'), variant: 'default' as const };
    return { label: t('studentDetails.scheduled'), variant: 'outline' as const };
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('studentDetails.title')}</DialogTitle>
          <DialogDescription>
            {t('studentDetails.description', { studentName: student.name })}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Student Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{t('studentDetails.studentInformation')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={student.avatar} alt={student.name} />
                  <AvatarFallback className="text-lg">{initials}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-xl font-semibold">{student.name}</h3>
                  <p className="text-muted-foreground">{t('studentDetails.studentId')}: {student.id}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Class Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{t('studentDetails.classInformation')}</CardTitle>
            </CardHeader>
            <CardContent>
              {classInfo ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{t('studentDetails.className')}</p>
                    <p className="text-lg">{classInfo.name}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{t('studentDetails.grade')}</p>
                    <p className="text-lg">{classInfo.grade}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{t('studentDetails.teacher')}</p>
                    <p className="text-lg">{classInfo.teacher}</p>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground">{t('studentDetails.noClassInfo')}</p>
              )}
            </CardContent>
          </Card>

          {/* Parent Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{t('studentDetails.parentGuardianInfo')}</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <p className="text-muted-foreground">{t('studentDetails.loadingParentInfo')}</p>
              ) : parentRelations.length > 0 ? (
                <div className="space-y-4">
                  {parentRelations.map((parent) => (
                    <div key={parent.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{parent.parentName}</h4>
                        <div className="flex gap-2">
                          {parent.isPrimary && (
                            <Badge variant="default">{t('studentDetails.primary')}</Badge>
                          )}
                          {parent.relationship && (
                            <Badge variant="secondary">{parent.relationship}</Badge>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                        {parent.parentEmail && (
                          <div>
                            <span className="font-medium">{t('studentDetails.email')}: </span>
                            <span className="text-muted-foreground">{parent.parentEmail}</span>
                          </div>
                        )}
                        {parent.parentPhone && (
                          <div>
                            <span className="font-medium">{t('studentDetails.phone')}: </span>
                            <span className="text-muted-foreground">{parent.parentPhone}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">{t('studentDetails.noParentInfo')}</p>
              )}
            </CardContent>
          </Card>

          {/* Pickup Authorizations */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="h-5 w-5" />
                {t('studentDetails.authorizedPickupParents')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Create Authorization Button (Always at top for admins) */}
                {isAdmin && (
                  <AdminAuthorizationForm
                    studentId={student.id}
                    studentName={student.name}
                    onAuthorizationCreated={handleAuthorizationCreated}
                  />
                )}

                {/* Authorization List */}
                {isLoading ? (
                  <p className="text-muted-foreground">{t('studentDetails.loadingPickupAuth')}</p>
                ) : pickupAuthorizations.length > 0 ? (
                  <div className="space-y-4">
                    {pickupAuthorizations.map((auth) => {
                      const status = getAuthorizationStatus(auth.startDate, auth.endDate);
                      return (
                        <div key={auth.id} className="p-4 border rounded-lg space-y-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold">{auth.authorizedParentName}</h4>
                              <p className="text-sm text-muted-foreground">{auth.authorizedParentEmail}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={status.variant}>{status.label}</Badge>
                              {isAdmin && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => deleteConfirmation.openDeleteConfirmation(auth)}
                                  disabled={deleteConfirmation.isLoading}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  {deleteConfirmation.isLoading && deleteConfirmation.itemToDelete?.id === auth.id ? (
                                    <>
                                      <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-red-600 mr-2"></div>
                                      {t('common.deleting')}
                                    </>
                                  ) : (
                                    t('common.delete')
                                  )}
                                </Button>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-muted-foreground" />
                              <span className="text-muted-foreground">
                                {formatDate(auth.startDate)} - {formatDate(auth.endDate)}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <span className="text-muted-foreground">
                                {t('studentDetails.created')} {formatDate(auth.createdAt)}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : !isAdmin ? (
                  <div className="text-center py-6">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">{t('studentDetails.noPickupAuth')}</h3>
                    <p className="text-gray-500">
                      {t('studentDetails.noPickupAuthDesc')}
                    </p>
                  </div>
                ) : null}
              </div>
            </CardContent>
          </Card>
        </div>

        <DeleteConfirmationDialog
          open={deleteConfirmation.isOpen}
          onOpenChange={deleteConfirmation.closeDeleteConfirmation}
          title={deleteConfirmation.getDialogTexts().title}
          description={deleteConfirmation.getDialogTexts().description}
          itemName={deleteConfirmation.getItemDisplayName()}
          isLoading={deleteConfirmation.isLoading}
          onConfirm={deleteConfirmation.handleConfirmDelete}
        />
      </DialogContent>
    </Dialog>
  );
};

export default StudentDetailsDialog;
