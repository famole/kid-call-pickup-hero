
-- First, add superadmin to the existing app_role enum
ALTER TYPE public.app_role ADD VALUE 'superadmin';
