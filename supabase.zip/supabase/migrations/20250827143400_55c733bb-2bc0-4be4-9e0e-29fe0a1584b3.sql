-- Add missing roles to the app_role enum
ALTER TYPE public.app_role ADD VALUE 'family';
ALTER TYPE public.app_role ADD VALUE 'other';