-- Clean up debug function and fix security warnings
DROP FUNCTION IF EXISTS public.debug_auth_state();