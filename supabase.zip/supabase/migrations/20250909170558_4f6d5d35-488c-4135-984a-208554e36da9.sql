-- Clean up debug function
DROP FUNCTION IF EXISTS public.debug_user_auth();